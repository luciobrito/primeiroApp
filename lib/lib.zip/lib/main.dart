import 'package:flutter/material.dart';
import 'package:mmyapp/historico.dart';
import 'package:mmyapp/home.dart';
import 'package:mmyapp/newpage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
      ),
      home: const MyHomePage(title: 'Meu app'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  int _indice = 0;
  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }
  final List<Widget> _telas = [
    Home(),
    NewPageScreen("Página 2"), 
    NewPageScreen("Página 3")
  ];
  void onTapped(int index){
    setState(() {
      _indice = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: _telas[_indice],
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indice,
        onTap: onTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.house), label: 'Inicio'),
          BottomNavigationBarItem(icon: Icon(Icons.add_box), label: 'Produtos'),
          BottomNavigationBarItem(icon: Icon(Icons.badge), label: 'Página 3')
        ],
      ),
    );
  }
}
