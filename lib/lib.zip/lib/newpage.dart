import 'package:flutter/widgets.dart';

class NewPageScreen extends StatelessWidget{
      final String texto;
      NewPageScreen(this.texto);
      @override
  Widget build(BuildContext context) {
    return Center(child: Text(texto),);
  }  
}